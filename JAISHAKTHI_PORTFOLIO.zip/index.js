

let id= document.getElementById("menu")
 


id.addEventListener('click',()=>{

   ul.classList.toggle('invisible');
  })